<footer class="p-4 text-white bg-gray-600">
        <div class="flex flex-col items-center gap-4 lg:flex-row lg:justify-between">
            <p class="text-center lg:text-left">Copyright © 2023 — All Rights Reserved for EasyOnlineHomeJobs</p>
            <ul class="flex items-center gap-4">
                <li><a class="hover:underline" href="privacy-policy.php">Privacy Policy</a></li>
                <li><a class="hover:underline" href="">Terms & Conditions</a></li>
            </ul>
        </div>
    </footer>
 <!-- <script type="text/javascript" src="//cdn.pubguru.com/fb.js"></script>
<script src="//m2d.m2.ai/pg.simplyearnonline.js" async> </script> -->