<div style="background-color: #FFFFFF; width: 100%;">
   <form method = "post" action="https://webform.elasticsendy.com/api/rest/signup-forms-pub/v3/MTU1MDAwMjAwMDAwNzcwMg==/add-contact" onsubmit="mpx_submitSignupForm(event)">
      <div style="max-width: 500px; margin: auto; background-color: #ffffff; border-radius: 0px; padding: 0px 0px 0px 0px ">
         <div id="mpx_error_global" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #ffffff; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 2px 0px " class="mpx_error">
         </div>
         <div style="position: relative">
            <div id="mpx_success_box" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #ffffff; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 2px 0px ; position: absolute; top: 30%; left: 5%; visibility: hidden;">
            </div>
            <div id="mpx_input_elmts_bx" style="visibility: visible; position: relative;">
               <div style="display: block">
                  <div style="display: block; font-family: Arial; font-size: 14px; color: #000000; background-color: #ffffff; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 2px 0px ">
                     Enter your name *
                  </div>
                  <div>
                     <input type="text" style="border: 1px; border-style: solid;  outline: none; width: 100%; font-family: Arial; font-size: 14px; background-color: #FFFFFF; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 10px 5px " name="mpx_param_name" placeholder="Name" required />
                  </div>
                  <div id="mpx_error_mpx_param_name" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #ffffff; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 2px 0px " class="mpx_error">
                  </div>
               </div>
               <div style="display: block">
                  <div style="display: block; font-family: Arial; font-size: 14px; color: #000000; background-color: #ffffff; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 2px 0px ">
                     Enter your email *
                  </div>
                  <div>
                     <input type="email" style="border: 1px; border-style: solid; outline: none; width: 100%; font-family: Arial; font-size: 14px; background-color: #FFFFFF; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 10px 5px " name="mpx_param_email" placeholder="Email" required />
                  </div>
                  <div id="mpx_error_mpx_param_email" style="font-family: Arial; font-size: 14px; color: #000000; background-color: #ffffff; text-align: left; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px 0px 2px 0px " class="mpx_error">
                  </div>
               </div>
               <div style="display: block">
                  <button id="mpx_submit_btn" type="submit" style="width: 100%; cursor: pointer; border: 0; font-family: Arial; font-size: 14px; color: #FFFFFF; background-color: #16a34a; text-align: center; font-weight: bold; font-style: normal; text-decoration: none; padding: 15px 60px 15px 60px ">SUBMIT</button>
                    <input type="hidden" id="mpx_onsubmit_redirect_url" value="https://app.simplyearnonline.com/thank-you.php"/>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
<!-- END ElasticSendy Signup Form -->
